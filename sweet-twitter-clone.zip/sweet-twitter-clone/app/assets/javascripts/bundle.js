/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	var FollowToggle = __webpack_require__ (1);
	var UsersSearch = __webpack_require__ (2);
	var TweetCompose = __webpack_require__ (3);
	
	$(function(){
	
	  $('button.follow-toggle').each(function(id, el){
	    new FollowToggle(el);
	  });
	
	  $('nav.users-search').each(function(id, el) {
	    new UsersSearch(el);
	  });
	
	  $('form.tweet-compose').each(function(id, el) {
	    new TweetCompose(el);
	  });
	
	});


/***/ },
/* 1 */
/***/ function(module, exports) {

	function FollowToggle($el) {
	  this.$el = $($el);
	  this.userId = this.$el.attr("data-user-id");
	  this.followState = this.$el.attr("data-follow-state");
	  // TODO ask next TA about how to do this in a better way
	  this.$el.on('click', this.handleClick.bind(this));
	  this.render();
	 }
	
	FollowToggle.prototype.handleClick = function (e) {
	  e.preventDefault();
	  if (this.followState === "unfollowed") {
	    this.followState = "following";
	    var ajaxType = "POST";
	  } else {
	    this.followState = "unfollowing";
	    ajaxType = "DELETE";
	  }
	  this.render();
	  $.ajax({
	    type: ajaxType,
	    url: "/users/" + this.userId + "/follow",
	    dataType: 'json',
	    data: {
	      userId: this.userId
	    },
	    success: function(data){
	      console.log(data);
	      this.toggleState();
	    }.bind(this),
	    error: function(data) {
	      console.log("ERROR");
	      console.log(data);
	    }
	  });
	};
	
	FollowToggle.prototype.toggleState = function () {
	  this.followState = this.followState === "followed" ?
	    "unfollowed" : "followed";
	  this.render();
	};
	
	FollowToggle.prototype.render = function () {
	  if (this.followState === "following" ||
	    this.followState === "unfollowing") {
	    this.$el.prop("disabled");
	  }
	
	  var bText = (this.followState === "followed" ||
	               this.followState === "following") ?
	               "Unfollow" : "Follow";
	
	  this.$el.text(bText);
	};
	
	module.exports = FollowToggle;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//hello


/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	var FollowToggle = __webpack_require__(1);
	
	function UsersSearch(el){
	  this.$el = $(el);
	  this.input = this.$el.find('[name=username]');
	  this.ul = this.$el.find('ul');
	  this.input.on("input", this.handleInput.bind(this));
	}
	
	UsersSearch.prototype.handleInput = function (e) {
	  e.preventDefault();
	  $.ajax({
	    type: "GET",
	    url: "search",
	    dataType: 'json',
	    data: {
	      query: this.input.val()
	    },
	    success: function(data) {
	      console.log(data);
	      this.renderResults(data);
	    }.bind(this),
	    error: function(data) {
	      console.log("ERROR");
	      console.log(data);
	    }
	  });
	};
	
	UsersSearch.prototype.renderResults = function (data) {
	  this.ul.empty();
	  var funUl = this.ul;
	  data.forEach(function(obj){
	    var funLi =
	      "<li><a href='" + obj.id + "'>" + obj.username + "</a></li>";
	    var followedText = obj.followed ? "followed" : "unfollowed";
	    var funButton =
	    "<button type='button' class='follow-toggle' name='button'" +
	    "data-user-id=" + obj.id + " data-follow-state=" + followedText + ">" +
	    "</button>";
	
	    funUl.append(funLi).append(funButton);
	  });
	  $('button.follow-toggle').each(function(id, el){
	
	    new FollowToggle(el);
	  });
	};
	
	module.exports = UsersSearch;


/***/ },
/* 3 */
/***/ function(module, exports) {

	function TweetCompose(el) {
	  this.$el = $(el);
	
	  this.$el.find("input[type=submit]").on("click", this.submit.bind(this));
	  this.$el.find(".tweet-content").on("input", this.charCount.bind(this));
	
	  this.$el.find(".add-mention").on("click", this.addMentionedUser.bind(this));
	  this.$el.find(".mentioned-users")
	    .on("click", ".remove-mention", this.removeMentionedUser.bind(this));
	}
	
	TweetCompose.prototype.submit = function (e) {
	  e.preventDefault();
	  var allInputs = this.$el.find(":input");
	  var data = allInputs.serializeJSON();
	  allInputs.prop('disable');
	  $.ajax({
	    type: 'POST',
	    dataType: 'json',
	    url: '/tweets',
	    data: data,
	    success: function(data1) {
	      this.handleSucess(data1);
	    }.bind(this),
	    error: function(data1) {
	      console.log("ERROR");
	      console.log(data1);
	    }
	  });
	};
	
	TweetCompose.prototype.handleSucess = function (data) {
	  this.clearInput();
	  var ulTag = this.$el.attr('data-tweetfinder');
	  var coolLi = "<li>" + JSON.stringify(data) + "</li>";
	  $("#" + ulTag).prepend(coolLi);
	};
	
	TweetCompose.prototype.clearInput = function () {
	  this.$el.find(":input").val('');
	  this.$el.find(":input").prop('disable');
	  this.$el.find(".mentioned-users").empty();
	};
	
	TweetCompose.prototype.charCount = function () {
	  var count = this.$el.find(".tweet-content").val().length;
	  var remaining = "Remaining Characters: " + (140 - count);
	  this.$el.find(".chars-left").text(remaining);
	};
	
	TweetCompose.prototype.addMentionedUser = function (e) {
	  e.preventDefault();
	  this.$el.find('.mentioned-users').append(this.$el.find('script').html());
	};
	
	TweetCompose.prototype.removeMentionedUser = function (e) {
	  e.preventDefault();
	  $(e.currentTarget).parent().remove();
	};
	
	module.exports = TweetCompose;


/***/ }
/******/ ]);
//# sourceMappingURL=bundle.js.map